const express = require("express");
const app = express();
const tarefasRoutes = require("./routes/tarefas");

app.use(express.json());

// rota principal
app.get("/", (req, res) => {
  res.send(" API de Agenda funcionando!");
});

// rotas de tarefas
app.use("/tarefas", tarefasRoutes);

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});