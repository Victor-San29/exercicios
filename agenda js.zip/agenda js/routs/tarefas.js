const express = require("express");
const router = express.Router();

let tarefas = [];
let id = 1;

//  Criar
router.post("/", (req, res) => {
  const { titulo, descricao } = req.body;

  const novaTarefa = {
    id: id++,
    titulo,
    descricao,
    concluida: false
  };

  tarefas.push(novaTarefa);
  res.status(201).json(novaTarefa);
});

// Listar 
router.get("/", (req, res) => {
  res.json(tarefas);
});

// Atualizar
router.put("/:id", (req, res) => {
  const tarefa = tarefas.find(t => t.id == req.params.id);

  if (!tarefa) {
    return res.status(404).json({ erro: "Tarefa não encontrada" });
  }

  const { titulo, descricao, concluida } = req.body;

  if (titulo !== undefined) tarefa.titulo = titulo;
  if (descricao !== undefined) tarefa.descricao = descricao;
  if (concluida !== undefined) tarefa.concluida = concluida;

  res.json(tarefa);
});

//  Deletar 
router.delete("/:id", (req, res) => {
  tarefas = tarefas.filter(t => t.id != req.params.id);
  res.json({ mensagem: "Tarefa removida com sucesso" });
});

module.exports = router;